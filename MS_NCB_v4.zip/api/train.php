
<?php

require_once "core/MultiModal.php";

use MSNCB\MultiModal;

header("Content-Type: application/json");

$mm=new MultiModal();

$epochs=intval($_POST["epochs"]??2);

$log=$mm->trainAll($epochs);

echo json_encode(["trained"=>true,"log"=>$log]);

?>
