
<?php

namespace MSNCB;

require_once "Stack.php";

class MultiModal {

  public array $stacks=[]; private array $interconnect=[];

  function __construct(){

    $cfg=json_decode(file_get_contents(__DIR__."/../../data/config.json"),true);

    foreach($cfg["modules"] as $m)

      $this->stacks[$m["name"]]=new Stack($m["name"],$m["inputs"],$m["outputs"],$m["lr"]);

    $this->interconnect=json_decode(file_get_contents(__DIR__."/../../data/interconnect.json"),true);

  }

  function forwardAll(array $inputs):array{

    $signals=[];

    foreach($this->stacks as $name=>$stack){

      $x=$inputs[$name]??array_fill(0,6,0);

      foreach($this->interconnect as $link)

        if($link["to"]==$name && isset($signals[$link["from"]]))

          $x=array_merge($x,$signals[$link["from"]]);

      $signals[$name.":out"]=$stack->forward($x);

    }

    return $signals;

  }

  function trainAll(int $epochs=1):array{

    $log=[];

    foreach($this->stacks as $name=>$stack){

      $data=json_decode(file_get_contents(__DIR__."/../../data/training_$name.json"),true);

      for($e=0;$e<$epochs;$e++)

        foreach($data as $d) $stack->train($d["input"],$d["target"]);

      $log[]="$name stack trained $epochs epochs";

    }

    return $log;

  }

}

?>
