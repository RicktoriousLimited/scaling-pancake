
<?php

namespace MSNCB;

require_once "Regression.php";

class Stack {

  public string $name; public array $regs=[]; public array $memory=[];

  public float $decay=0.8;

  function __construct(string $name,int $inputs=6,int $outputs=3,float $lr=0.05){

    $this->name=$name;

    for($i=0;$i<$outputs;$i++)

      $this->regs[]=array_fill(0,$inputs,new Regression($lr));

    $this->memory=array_fill(0,$outputs,0.0);

  }

  function forward(array $x):array{

    $out=[];

    foreach($this->regs as $neuron){

      $sum=0; foreach($neuron as $r=>$reg) $sum+=$reg->predict($x[$r]??0);

      $out[]=$sum/count($neuron);

    }

    foreach($out as $i=>$o)

      $this->memory[$i]=$this->decay*$this->memory[$i]+(1-$this->decay)*$o;

    return $out;

  }

  function train(array $x,array $y):void{

    foreach($this->regs as $i=>$neuron)

      foreach($neuron as $j=>$reg)

        $reg->update($x[$j]??0,$y[$i]??0);

  }

}

?>
