
<?php

namespace MSNCB;

class Regression {

  public float $slope; public float $intercept; public float $lr;

  function __construct(float $lr=0.05){

    $this->slope=mt_rand()/mt_getrandmax()*0.5;

    $this->intercept=0; $this->lr=$lr;

  }

  function predict(float $x):float { return $this->slope*$x+$this->intercept; }

  function update(float $x,float $y):void{

    $pred=$this->predict($x); $err=$y-$pred;

    $this->slope+=$this->lr*$err*$x; $this->intercept+=$this->lr*$err;

  }

}

?>
