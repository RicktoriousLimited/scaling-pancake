
<?php

require_once "core/MultiModal.php";

use MSNCB\MultiModal;

header("Content-Type: application/json");

$mm=new MultiModal();

$in=json_decode($_POST["inputs"]??"{}",true);

$out=$mm->forwardAll($in);

echo json_encode(["signals"=>$out]);

?>
